from userInputs import num1, num2
from outputs import calculate
calculate(num1,num2)
