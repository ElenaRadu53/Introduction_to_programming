num1=int(input("Enter your first number"))
num2=int(input("Enter your second number"))
